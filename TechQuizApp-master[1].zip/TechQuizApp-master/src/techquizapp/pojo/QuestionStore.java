/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.pojo;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author vikrant
 */
public class QuestionStore {

    ArrayList<QuestionPojo> questionList=new ArrayList<>();
    
    @Override
    public String toString() {
        return "QuestionStore{" + "questionList=" + questionList + '}';
    }
    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.questionList);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final QuestionStore other = (QuestionStore) obj;
        if (!Objects.equals(this.questionList, other.questionList)) {
            return false;
        }
        
        return true;
    }
    public QuestionStore(){
    
    }
    public QuestionStore(ArrayList<QuestionPojo> questionList) {
        this.questionList = questionList;
    }

    public ArrayList<QuestionPojo> getQuestionList() {
        return questionList;
    }

    public void setQuestionList(ArrayList<QuestionPojo> questionList) {
        this.questionList = questionList;
    }
    
    public void addQuestion(QuestionPojo que){
        questionList.add(que);
    }
    public QuestionPojo getQuestion(int pos){
        return questionList.get(pos);
    }
    public void removeQuestion(int pos){
       questionList.remove(pos);
    }
    public void setQuestionAt(int pos,QuestionPojo q){
        questionList.add(pos, q);
    }
    public ArrayList<QuestionPojo> getAllQuestions(){
        return questionList;
    }
    public int getCount(){
        return questionList.size();
    }
    public boolean findQuestionbyqno(QuestionPojo q){
        return questionList.contains(q);
    }
   
    
}
