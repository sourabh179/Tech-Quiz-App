/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author vikrant
 */
public class DBConnection {

    private static Connection con;

    static {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            JOptionPane.showMessageDialog(null, "Class Load Successfully");
            con = DriverManager.getConnection("jdbc:oracle:thin:@//DESKTOP-KIKS60P:1521/XE","quizapp", "quizapp");
            JOptionPane.showMessageDialog(null, "Connection Successfully");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Exception Occured in static Block");
        }
    }

    public static Connection getConnection() {
        return con;
    }

    public static void closeConnection() {
        try {
            con.close();
            JOptionPane.showMessageDialog(null, "Disconnected Successfully");

        }
        catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Exception Occured in closeConnection");
        }
    }

}
