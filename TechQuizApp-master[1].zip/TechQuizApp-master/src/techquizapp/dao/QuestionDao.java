/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import techquizapp.dbutil.DBConnection;
import techquizapp.pojo.QuestionPojo;
import techquizapp.pojo.QuestionStore;

/**
 *
 * @author vikrant
 */
public class QuestionDao {
    public static void addQuestions(QuestionStore qStore)throws Exception{
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("insert into questions values(?,?,?,?,?,?,?,?,?)");
        ArrayList<QuestionPojo> questionList=qStore.getAllQuestions();
        for(QuestionPojo obj:questionList){
            ps.setString(1, obj.getExmId());
            ps.setInt(2,obj.getQno());
            ps.setString(3, obj.getQuestion());
            ps.setString(4, obj.getAnswer1());
            ps.setString(5, obj.getAnswer2());
            ps.setString(6,obj.getAnsweer3());
            ps.setString(7,obj.getAnswer4());
            ps.setString(8,obj.getCorrectAnswer());
            ps.setString(9,obj.getLanguage());
            ps.executeUpdate();
        }   
    }
    public static boolean updateQuestion(QuestionStore qstore)throws Exception{
        Connection co=DBConnection.getConnection();
        PreparedStatement ps=co.prepareStatement("update questions set examid=?,qno=?,question=?,answer1=?,answer2=?,answer3=?,answer4=?,correctanswer=?,language=? where qno=? and examid=?");
        ArrayList<QuestionPojo> questionList=qstore.getAllQuestions();
        boolean status=false;
        for(QuestionPojo obj:questionList){
            ps.setString(1, obj.getExmId());
            ps.setInt(2,obj.getQno());
            ps.setString(3, obj.getQuestion());
            ps.setString(4, obj.getAnswer1());
            ps.setString(5, obj.getAnswer2());
            ps.setString(6,obj.getAnsweer3());
            ps.setString(7,obj.getAnswer4());
            ps.setString(8,obj.getCorrectAnswer());
            ps.setString(9,obj.getLanguage());
            ps.setInt(10,obj.getQno());
            ps.setString(11,obj.getExmId());
            ps.executeUpdate();
            status=true;
        }
        return status;
    }
    public static ArrayList<QuestionPojo> getQuestionsByExamId(String examid)throws Exception{
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("Select * from questions where examid=? order by qno");
        ps.setString(1,examid);
        ArrayList<QuestionPojo> queList=new ArrayList<>();
        
        ResultSet rs=ps.executeQuery();
        
        while(rs.next()){
            
            QuestionPojo que=new QuestionPojo();
            que.setExmId(examid);
            que.setQno(rs.getInt(2));
            que.setQuestion(rs.getString(3));
            que.setAnswerq(rs.getString(4));
            que.setAnswer2(rs.getString(5));
            que.setAnsweer3(rs.getString(6));
            que.setAnswer4(rs.getString(7));
            que.setCorrectAnswer(rs.getString(8));
            que.setLanguage(rs.getString(9));
            queList.add(que);
        
        }
        
        return queList;
    }
    
}
