/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import techquizapp.dbutil.DBConnection;
import techquizapp.pojo.UserPojo;

/**
 *
 * @author vikrant
 */
public class userDao {
    public static Boolean validateUser(UserPojo u)throws Exception{
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("select * from users where userid=? and password=? and usertype=?");
        ps.setString(1, u.getUserid());
        ps.setString(2, u.getPassword());
        ps.setString(3,u.getUsertype());
        ResultSet rs=ps.executeQuery();
        String username=null;
        return rs.next();
    }
    public static boolean addUser(String userid,String pwd)throws Exception {
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("insert into users values(?,?,'Student')");
        ps.setString(1,userid);
        ps.setString(2,pwd);
        int status=ps.executeUpdate();
        return (status==1);
    }
    public static boolean updatePwd(String userid,String pwd)throws Exception{
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("update users set password=? where userid=?");
        ps.setString(1, pwd);
        ps.setString(2, userid);
        int status=ps.executeUpdate();
        return (status==1);
        
    }
    
    
}
