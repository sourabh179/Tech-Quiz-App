/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import techquizapp.dbutil.DBConnection;
import techquizapp.pojo.ExamPojo;

/**
 *
 * @author vikrant
 */
public class ExamDao {
    
    public static String getExamId()throws Exception{
        Connection con=DBConnection.getConnection();
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select count(*) as totalrows from exam");
        int rowcount=0;
        if(rs.next()){
            rowcount=rs.getInt(1);
            
        }
        rowcount+=1;
        String id="EX-"+rowcount;
        
        return id;
        
    }
    public static ArrayList<String> getExamBySubjects(String language,String userid)throws SQLException{
        Connection con=DBConnection.getConnection();
        System.out.println("lang: "+language+"\tuserid: "+userid);
        PreparedStatement ps=con.prepareStatement("select examid from exam where language=? minus select examid from performance where userid=?");
        ps.setString(1, language);
        ps.setString(2, userid);
        ResultSet rs=ps.executeQuery();
        ArrayList<String> examIds=new ArrayList<>();
        while(rs.next()){
            String id=rs.getString(1);
            examIds.add(id);
        }
        return examIds;
    }
    public static boolean addExam(ExamPojo newExam)throws Exception{
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("insert into Exam values(?,?,?)");
        ps.setString(1, newExam.getExamId());
        ps.setString(2, newExam.getLanguage());
        ps.setInt(3, newExam.getTotalQuestion());
        int status=ps.executeUpdate();
        return status==1;
    }
    public static ArrayList<String> getLanguages()throws Exception{
        ArrayList<String> languageList=new ArrayList<>();
        Connection con=DBConnection.getConnection();
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("Select distinct language from exam");
        while(rs.next()){
            String lng=rs.getString("language");
            languageList.add(lng);
        }
        return languageList; 
    }
    public static int getQuestionCountByExam(String examId)throws SQLException{
        String qry="select totalquestion from Exam where examid=?";
        Connection conn=DBConnection.getConnection();
          PreparedStatement ps=conn.prepareStatement(qry);
          ps.setString(1,examId);
          ResultSet rs=ps.executeQuery();
	    rs.next();
          int rowCount=rs.getInt(1);
          return rowCount;
        }

}
