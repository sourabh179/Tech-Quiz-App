/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import techquizapp.dbutil.DBConnection;
import techquizapp.pojo.PerformancePojo;
import techquizapp.pojo.StudentScore;

/**
 *
 * @author vikrant
 */
public class performanceDao {
    public static ArrayList<String> getAllStudent()throws Exception{
       ArrayList<String> userId=new ArrayList<>();
        Connection con=DBConnection.getConnection();
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("Select distinct userid from performance");
        while(rs.next()){
            String sid=rs.getString(1);
            System.out.println(sid);
            userId.add(sid);
        }
        return userId; 
    }
    public static ArrayList<String> getAllExamId(String StudentId)throws Exception{
        ArrayList<String> examId=new ArrayList<>();
        Connection con=DBConnection.getConnection();
        System.out.println("Student id: "+StudentId);
        PreparedStatement ps=con.prepareStatement("Select examid from performance where userid=?");
        ps.setString(1, StudentId);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
            String exmid=rs.getString("examid");
            examId.add(exmid);
        }
        return examId;
    }
    public static StudentScore getScore(String stuId,String exmId)throws Exception{
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("select language,per from performance where userid=? and examid=?");
        ps.setString(1, stuId);
        ps.setString(2, exmId);
        ResultSet rs=ps.executeQuery();
        rs.next();
        StudentScore scoreObj=new StudentScore();
        scoreObj.setLanguage(rs.getString("language"));
        scoreObj.setPer(rs.getDouble("per"));
        return scoreObj;
    }
    public static boolean addPerformance(PerformancePojo performance)throws Exception {
        Connection con=DBConnection.getConnection();
        PreparedStatement ps=con.prepareStatement("insert into performance values(?,?,?,?,?,?,?)");
        ps.setString(1,performance.getUserid());
        ps.setString(2,performance.getExamid());
        ps.setInt(3,performance.getRight());
        ps.setInt(4,performance.getWrong());
        ps.setInt(5,performance.getUnattempted());
        ps.setDouble(6,performance.getPer());
        ps.setString(7,performance.getLanguage());
        int status=ps.executeUpdate();
        
        return (status==1);
        
    }
      public static ArrayList<PerformancePojo> getAllScore()throws Exception{
        Connection con=DBConnection.getConnection();
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from performance");
        ArrayList<PerformancePojo> pList=new ArrayList<>();
        while(rs.next()){
            PerformancePojo p=new PerformancePojo();
            p.setUserid(rs.getString(1));
            p.setExamid(rs.getString(2));
            p.setPer(rs.getDouble(6));
            p.setLanguage(rs.getString(7));
            pList.add(p);
        }
        return pList;
    }
}
